RetroBlaster - 2.0 and up
-------------------------

Two quick things before you run your RetroBlaster software:

Before you use the RetroBlaster software for the first time, make sure you are running Microsoft .NET Framework of at least version 4.0. If you don't have it, or aren't sure, the Microsoft .NET 4.0 update is included in the drivers folder included with this software.

If you aren't running .NET 4.0 or higher, you'll have errors when using this software. This is due to some features the software uses that run on .NET 4.0 framework.

Also, if you're running Windows 7 or earlier, you may need to install the "serial_install.exe" program, which installs the Virtual Serial port drivers. A compatible driver from Windows is usually found, but if the programmer is not showing up in Device Manager->Ports, installing this driver will fix that. It's located in the Drivers folder, and you need to "Run As Administrator" in order for the install to go through.

Any questions or problems with that, please email your question to support@retrostage.net

-------------------------------------------------------
-------------------------------------------------------
RetroStage Computing
(c) 2020
-------------------------------------------------------
-------------------------------------------------------
