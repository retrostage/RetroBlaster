RetroBlaster 2.0
-------------------------

A quick thing before you run your RetroBlaster 2.0 software:

Before you use the RetroBlaster 2.0 software for the first time, make sure you are running Microsoft .NET Framework of at least version 4.0. If you don't have it, or aren't sure, the Microsoft .NET 4.0 update is included in the drivers folder included with this software.

If you aren't running .NET 4.0 or higher, you'll have errors when using this software. This is due to some features the software uses that run on .NET 4.0 framework.

Any questions or problems with that, please email your question to snesrepros@gmail.com

-------------------------------------------------------
-------------------------------------------------------
RetroStage Computing
(c) 2019
-------------------------------------------------------
-------------------------------------------------------
