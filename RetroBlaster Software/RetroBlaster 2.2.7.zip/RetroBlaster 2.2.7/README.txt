RetroBlaster Mini
-------------------------

Two quick things before you run your RetroBlaster software:

1) Before you use the RetroBlaster software for the first time, make sure you are running Microsoft .NET Framework of at least version 4.0. If you don't have it, or aren't sure, the Microsoft .NET 4.0 update is included in the drivers folder included with this software.

If you aren't running .NET 4.0 or higher, you'll have errors when using this software. This is due to some features the software uses that run on .NET 4.0 framework.

For .NET framework, visit:
https://dotnet.microsoft.com/en-us/download/dotnet-framework/net481

2) If the RetroBlaster software isn't recognizing the RetroBlaster Mini, you may need to install a VCP (virtual com port) driver for your PC. 

Visit: https://ftdichip.com/drivers/vcp-drivers/

Select the driver for your OS version - Windows (Universal) for 64bit is the most common for Windows PC users.

Any questions or problems with that, please email your question to support@retrostage.net

-------------------------------------------------------
-------------------------------------------------------
RetroStage Computing
(c) 2025
-------------------------------------------------------
-------------------------------------------------------
